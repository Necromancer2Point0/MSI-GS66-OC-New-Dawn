--- === hs.hash ===
---
--- Various hashing algorithms

local hash = require "hs.libhash"
return hash
