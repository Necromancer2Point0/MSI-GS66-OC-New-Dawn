--- === hs.spaces ===
---
--- Controls for macOS Spaces. Currenly only used by `hs.spaces.watcher`. 

local spaces = {}

spaces.watcher = require "hs.libspaceswatcher"

return spaces
